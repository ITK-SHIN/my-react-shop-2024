import React from 'react';
import Products from '../components/Products';

const Captain = () => {
  return (
    <>
      <Products category="captain" />;
    </>
  );
};

export default Captain;

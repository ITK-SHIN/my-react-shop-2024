import React from 'react';
import Products from '../components/Products';

const SpiderMan = () => {
  return (
    <>
      <Products category="spider" />;
    </>
  );
};

export default SpiderMan;
